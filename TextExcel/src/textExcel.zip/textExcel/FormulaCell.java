package textExcel;

public class FormulaCell extends RealCell {

	public FormulaCell(String val) {
		super(val);
	}

}
